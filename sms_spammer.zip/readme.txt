Note :

1. If you can't use this tool install following pip packages....
	Command :- pip install random
	Command :- pip install requests

2. Enter your phone number list to phone_numbers.txt or generate them from sms carder tool.

3. You can validate your numbers from this tool & after validated numbers save in valid_numbers.txt file.

4. If you can't validate any mobile number, you need to change X-RapidAPI-Key
   You can get a X-RapidAPI-Key from https://rapidapi.com/Veriphone/api/veriphone/pricing
   ~ you can get a free api from there. 
   ~ don't create organization account if you need free api but limited.
   ~ In free plan you can send 1000 only for a month. You can buy a premium one.

5. If you can't a send a message using this tool. Don't worry. Create a account on https://app.d7networks.com/
   And after go to https://app.d7networks.com/developer/applications . and get token after creating account.
Contact : rowdyygaming@gmail.com
