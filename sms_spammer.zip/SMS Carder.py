import requests
import random

# -------------------------------------------------------------------------

# API SECTION - GET YOUR API FROM https://rapidapi.com/Veriphone/api/veriphone/pricing

XRapidAPIKey = "1c0da5d961msh2114d58cf62fa3fp1e396ajsnfe68663e864e"

# If you need to change api change above value in double quotes....

# -------------------------------------------------------------------------

# TOKEN SECTION

Token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJhdXRoLWJhY2tlbmQ6YXBwIiwic3ViIjoiMDZmMWQxYzQtM2I1MS00NTBhLWJmMjctZDdiNGVlMGIxZDE3In0.bnUn0GCsIna9ZdfpnCvwbv01YJCqCNWbxvhpyG3WzjI"

# IF YOU NEED TO CHANGE SMS TOKEN CHANGE ABOVE TOKEN VALUE IN double quotes.

# -------------------------------------------------------------------------

print("Welcome to num validator tool...")
print("--------------------------------")
print("Select the number")
print("1. Phone number generator")
print("2. Num Validator")
print("3. Get Phone Number Details")
print("4. Send a Message")
print("")
def choice():
    choice1 = int(input(":- "))
    print("")
    return choice1

x = choice()

if(x == 1):
    print("Generate phone numbers. But, you must input country code.")
    cc = input("Country Code (Eg: +1): ")
    n = int(input("Quantity of numbers: "))
    def random_phone_num_generator():
        first = str(random.randint(100, 999))
        second = str(random.randint(1, 888)).zfill(3)
        last = (str(random.randint(1, 9998)).zfill(4))
        while last in ['1111', '2222', '3333', '4444', '5555', '6666', '7777', '8888']:
            last = (str(random.randint(1, 9998)).zfill(4))
        return '{}{}{}'.format(first, second, last)
    file = open("phone_numbers.txt","a")
    for i in range(0, n):
        numbers = cc + str(random_phone_num_generator()) + "\n"
        file.write(numbers)
    file.close()
    
elif(x == 2):
    print("Validating the numbers from phone_numbers.txt file ....")
    print("------------------------")
    f = open("phone_numbers.txt", "r")
    for x in f:
        url = "https://veriphone.p.rapidapi.com/verify"

        querystring = {"phone":x}
        
        headers = {
                 "X-RapidAPI-Key": XRapidAPIKey,
                 "X-RapidAPI-Host": "veriphone.p.rapidapi.com"
      }
        response = requests.request("GET", url, headers=headers, params=querystring)
        fn = response.text
        file2 = open("valid_numbers.txt","a")
        if("true" in fn):
            file2.write(x)
        file2.close()

elif(x == 3):
    num = input("Phone Number : ")
    url = "https://veriphone.p.rapidapi.com/verify"

    querystring = {"phone":num}

    headers = {
                "X-RapidAPI-Key": "1c0da5d961msh2114d58cf62fa3fp1e396ajsnfe68663e864e",
                "X-RapidAPI-Host": "veriphone.p.rapidapi.com"
    }
    response = requests.request("GET", url, headers=headers, params=querystring)
    print(response.text)
    print("")
elif(x == 4):
    number1 = input("Phone Number : ")
    print("We are getting your message from messages.txt file. If you need to change the message go fast & change it.")
    msg1 = input("Are u ready to send ? (Y/n) : ")
    if(msg1 == 'y' or msg1=='Y' or msg1=='yes' or msg1=='Yes' or msg1=='YES'):
        url = "https://d7sms.p.rapidapi.com/messages/v1/send"
        file5 = open("messages.txt", "r")
        x5 = file5.read()
        payload = {"messages": [
                        {
                                "channel": "sms",
                                "originator": "SMS",
                                "recipients": [number1],
                                "content": x5,
                                "msg_type": "text"
                        }
                ]}
        headers = {
                "content-type": "application/json",
                "Token": Token,
                "X-RapidAPI-Key": "1c0da5d961msh2114d58cf62fa3fp1e396ajsnfe68663e864e",
                "X-RapidAPI-Host": "d7sms.p.rapidapi.com"
        }
        file5.close()
        response = requests.request("POST", url, json=payload, headers=headers)

        print(response.text)
    else:
        print("Ok, we are going to main menu.")
        print("------------------------------")
        choice()
    
else:
    print("Wrong choice... Try again")
    print("")
    choice()




